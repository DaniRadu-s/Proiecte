import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Calculator implements ActionListener {

    JFrame frame;
    JTextField textField;
    JButton[] nmbuttons = new JButton[10];
    JButton[] fctbuttons = new JButton[14];
    JButton addbutton,subbutton,mulbutton,divbutton,powbutton,modbutton,percbutton,radbutton,delbutton,
    backbutton,commabutton,equalbutton,delebutton, oppobutton;
    JPanel panel;

    Font myFont = new Font("Arial",Font.BOLD,20);

    double num1=0, num2=0, rez = 0;
    char op;

    public Calculator(){
        frame = new JFrame("Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 600);
        frame.setLayout(null);

        textField = new JTextField();
        textField.setFont(myFont);
        textField.setBounds(50,25,600,50);
        frame.add(textField);
        textField.setEditable(false);

        textField.setText("0");
        addbutton = new JButton("+");
        subbutton = new JButton("-");
        mulbutton = new JButton("X");
        divbutton = new JButton("/");
        powbutton = new JButton("x^2");
        modbutton = new JButton("%");
        percbutton = new JButton("1/x");
        radbutton = new JButton("sqrt(x)");
        delbutton = new JButton("C");
        delebutton = new JButton("CE");
        oppobutton = new JButton("+/-");
        backbutton = new JButton("<-");
        commabutton = new JButton(".");
        equalbutton = new JButton("=");

        fctbuttons[0]=addbutton;
        fctbuttons[1]=subbutton;
        fctbuttons[2]=mulbutton;
        fctbuttons[3]=divbutton;
        fctbuttons[4]=powbutton;
        fctbuttons[5]=modbutton;
        fctbuttons[6]=percbutton;
        fctbuttons[7]=radbutton;
        fctbuttons[8]=delbutton;
        fctbuttons[9]=backbutton;
        fctbuttons[10]=commabutton;
        fctbuttons[11]=equalbutton;
        fctbuttons[12]=delebutton;
        fctbuttons[13]=oppobutton;

        for(int i = 0; i<14;i++)
        {
            fctbuttons[i].addActionListener(this);
            fctbuttons[i].setFont(myFont);
            fctbuttons[i].setFocusable(false);
        }

        for(int i = 0; i<10;i++)
        {
            nmbuttons[i] = new JButton(String.valueOf(i));
            nmbuttons[i].addActionListener(this);
            nmbuttons[i].setFont(myFont);
            nmbuttons[i].setFocusable(false);
        }

        panel = new JPanel();
        panel.setBounds(50,100,600,600);
        panel.setLayout(new GridLayout(6,4,10,10));

        panel.add(modbutton);
        panel.add(delebutton);
        panel.add(delbutton);
        panel.add(backbutton);
        panel.add(percbutton);
        panel.add(powbutton);
        panel.add(radbutton);
        panel.add(divbutton);
        panel.add(nmbuttons[7]);
        panel.add(nmbuttons[8]);
        panel.add(nmbuttons[9]);
        panel.add(mulbutton);
        panel.add(nmbuttons[4]);
        panel.add(nmbuttons[5]);
        panel.add(nmbuttons[6]);
        panel.add(subbutton);
        panel.add(nmbuttons[1]);
        panel.add(nmbuttons[2]);
        panel.add(nmbuttons[3]);
        panel.add(addbutton);
        panel.add(oppobutton);
        panel.add(nmbuttons[0]);
        panel.add(commabutton);
        equalbutton.setBackground(Color.BLUE);
        panel.add(equalbutton);

        frame.add(panel);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        Calculator calc = new Calculator();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        for(int i = 0; i<10;i++){
            if(e.getSource()==nmbuttons[i]){
                textField.setText(textField.getText().concat(String.valueOf(i)));
            }
        }
        if(e.getSource() == commabutton){
            if(!textField.getText().contains("."))
                textField.setText(textField.getText().concat("."));
        }
        if(e.getSource() == addbutton){
            num1 = Double.parseDouble(textField.getText());
            op = '+';
            textField.setText("");
        }
        if(e.getSource() == subbutton){
            num1 = Double.parseDouble(textField.getText());
            op = '-';
            textField.setText("");
        }
        if(e.getSource() == mulbutton){
            num1 = Double.parseDouble(textField.getText());
            op = 'X';
            textField.setText("");
        }
        if(e.getSource() == divbutton){
            num1 = Double.parseDouble(textField.getText());
            op = '/';
            textField.setText("");
        }
        if(e.getSource() == powbutton){
            num1 = Double.parseDouble(textField.getText());
            rez = num1*num1;
            textField.setText(String.valueOf(rez));
        }
        if(e.getSource() == modbutton){
            num1 = Double.parseDouble(textField.getText());
            op = '%';
            textField.setText("");
        }
        if(e.getSource() == percbutton){
            num1 = Double.parseDouble(textField.getText());
            rez = 1/num1;
            textField.setText(String.valueOf(rez));
        }
        if(e.getSource() == radbutton){
            num1 = Double.parseDouble(textField.getText());
            rez = Math.sqrt(num1);
            textField.setText(String.valueOf(rez));
        }
        if(e.getSource() == delbutton){
            textField.setText("");
        }
        if(e.getSource() == backbutton){
            String str = textField.getText();
            textField.setText(str.substring(0,str.length()-1));
        }
        if(e.getSource() == delebutton){
            textField.setText("");
        }
        if(e.getSource() == oppobutton){
            double temp = Double.parseDouble(textField.getText());
            temp*=-1;
            textField.setText(String.valueOf(temp));
        }
        if(e.getSource() == equalbutton){
            num2 = Double.parseDouble(textField.getText());
            switch(op){
                case '+':
                    rez = num1 + num2;
                    break;
                case '-':
                    rez = num1 - num2;
                    break;
                case 'X':
                    rez = num1 * num2;
                    break;
                case '/':
                    rez = num1 / num2;
                    break;
                case '%':
                    rez = num1 % num2;
                    break;
            }
            textField.setText(String.valueOf(rez));
        }
    }
}
