#include "domain.h"

string Masina::getNrInmat() const {
	return nrInmat;
};

string Masina::getProd() const {
	return prod;
};

string Masina::getModel() const {
	return model;
};

string Masina::getTip() const {
	return tip;
};

void Masina::setNrInmat(const string& newNrInmat) {
	nrInmat = newNrInmat;
}

void Masina::setProd(const string& newProd) {
	prod = newProd;
}

void Masina::setModel(const string& newModel) {
	model = newModel;
}

void Masina::setTip(const string& newTip) {
	tip = newTip;
}
