#include "Masina.h"

GUI::GUI(MasinaService& srv) : serv(srv) {
	init();
	init_connect();
	loaddata(serv.getAllservice());
	loaddatarnd();
}

GUI::~GUI()
{}

SecondWindow::SecondWindow(MasinaService& srv) : serv(srv) {
	init1();
	init1_connect();
	loaddata1(serv.getAllservice());
}

QCos::QCos(MasinaService& srv) : serv(srv) {
	 init_cos();
	 init_connect_cos();
	 updateObserver();
}

QCos::~QCos()
{}

Table::Table(MasinaService& srv) : serv(srv) {
	init();
	init_connect();
	loaddata1(serv.getAllservice());
}