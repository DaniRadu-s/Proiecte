#pragma once
#include "domain.h"
#include <vector>
#include <exception>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <chrono>
#include <random>
using namespace std;

class Cos {
private:
	vector<Masina> masinicos;
public:
	void adaugare_cos(Masina mas);
	void golire();
	void generare_random(int n, vector<Masina> l);
	vector<Masina>&getCos();
};
class RepoAbstract {
public:
	RepoAbstract() = default;
	virtual void adaugare_repo(Masina mas) = 0;
	virtual void stergere_repo(const string& nrinmat)  = 0;
	virtual void modificare_repo(const string& nrinmatvechi, const string& nrinmatnou, const string& prod, const string& model, const string& tip) = 0;
	virtual const vector<Masina>& getAll() noexcept = 0;
};

class MasinaRepo : public RepoAbstract {
private:
	vector<Masina> masini;
public:
	MasinaRepo() = default;
	virtual void adaugare_repo(Masina mas) override;
	virtual void stergere_repo(const string& nrinmat) override;
	virtual void modificare_repo(const string& nrinmatvechi, const string& nrinmatnou, const string& prod, const string& model, const string& tip) override;
	vector<Masina>& getAll() noexcept override;
};

class Repofile : public MasinaRepo {
private:
	string filename;
public:
	Repofile(string file): MasinaRepo(), filename { file }{
		load_from_file();
	}
	void load_from_file();
	void save_to_file();
	void adaugare_repo(Masina mas) override;
	void stergere_repo(const string& nrinmat) override;
	void modificare_repo(const string& nrinmatvechi, const string& nrinmatnou, const string& prod, const string& model, const string& tip) override;
};