#include "Masina.h"
#include <QtWidgets/QApplication>

int main(int argc, char* argv[])
{
    QApplication a(argc, argv);
    Repofile repo{"masini.txt"};
    Cos c;
    MasinaService srv{ repo , c};
    GUI w{ srv };
    w.show();
    return a.exec();
}
