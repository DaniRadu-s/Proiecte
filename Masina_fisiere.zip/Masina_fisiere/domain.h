#pragma once
#include <string>
using namespace std;
class Masina {
private:
	string nrInmat, prod, tip, model;
public:
	Masina(string nr, string p, string m, string t) : nrInmat{ nr }, prod{ p }, model{ m }, tip{ t } {}
	string getNrInmat() const;
	string getProd() const;
	string getModel() const;
	string getTip() const;
	void setNrInmat(const string& newNrInmat);
	void setProd(const string& newProd);
	void setModel(const string& newModel);
	void setTip(const string& newTip);
};