#pragma once
#include "service.h"
#include "Undo.h"
#include <assert.h>

void testAll();