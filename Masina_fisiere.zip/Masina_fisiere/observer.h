#pragma once
#include <vector>
using std::vector;
class Observer
{
public:
	virtual void updateObserver() = 0;
};

class Observable {
	vector<Observer*> obs;
public:
	void notify() {
		for (auto o : obs)
			o->updateObserver();
	}
	void addObserver(Observer* o) {
		obs.push_back(o);
	}
};

