#include "test.h"
void test_domain() {
	Masina m = { "p","p","p","p" };
	assert(m.getNrInmat() == "p");
	assert(m.getModel() == "p");
	assert(m.getProd() == "p");
	assert(m.getTip() == "p");
}

void test_add() {
	MasinaRepo repo;
	Cos c;
	MasinaService serv{ repo , c };
	serv.adaugare_service("a", "a", "a", "a");
	assert(serv.getAllservice().size() == 1);
	string str;
	try {
		serv.adaugare_service("a", "b", "b", "b");
		assert(false);
	}
	catch (const exception e) {
		str = "Masina exista deja.\n";
		assert(str == e.what());
	}
}

void test_stergere() {
	MasinaRepo repo;
	Cos c;
	MasinaService serv{ repo , c };
	serv.adaugare_service("a", "a", "a", "a");
	serv.stergere_service("a");
	assert(serv.getAllservice().size() == 0);
	string str;
	try {
		serv.stergere_service("a");
		assert(false);
	}
	catch (const exception e) {
		str = "Masina nu exista.\n";
		assert(str == e.what());
	}
}

void test_modificare() {
	MasinaRepo repo;
	Cos c;
	MasinaService serv{ repo , c };
	serv.adaugare_service("a", "a", "a", "a");
	serv.modificare_service("a","b","b","b","b");
	assert(serv.getAllservice()[0].getNrInmat() == "b");
	string str;
	try {
		serv.modificare_service("a","c","c","c","c");
		assert(false);
	}
	catch (const exception e) {
		str = "Masina nu exista.\n";
		assert(str == e.what());
	}
}

void test_Undo() {
	MasinaRepo repo;
	Cos c;
	MasinaService serv{ repo , c };
	serv.adaugare_service("a", "a", "a", "a");
	serv.modificare_service("a", "b", "b", "b", "b");
	serv.stergere_service("b");
	assert(serv.getAllservice().size() == 0);
	serv.Undo();
	assert(serv.getAllservice()[0].getNrInmat() == "b");
	serv.Undo();
	assert(serv.getAllservice()[0].getNrInmat() == "a");
	serv.Undo();
	assert(serv.getAllservice().size() == 0);
	string str;
	try {
		serv.Undo();
		assert(false);
	}
	catch (const exception e) {
		str = "Nu se mai poate face Undo.\n";
		assert(str == e.what());
	}
}

void test_sortare() {
	MasinaRepo repo;
	Cos c;
	MasinaService serv{ repo , c };
	serv.adaugare_service("a", "b", "a", "a");
	serv.adaugare_service("b", "a", "b", "b");
	vector<Masina> vec;
	vec = serv.sortare(MasinaService::cmpnrinmat);
	assert(vec[0].getNrInmat() == "a");
	vec = serv.sortare(MasinaService::cmpprod);
	assert(vec[0].getNrInmat() == "b");
	vec = serv.sortare(MasinaService::cmptipmodel);
	assert(vec[0].getNrInmat() == "a");
	serv.stergere_service("a");
	serv.stergere_service("b");
	serv.adaugare_service("b", "a", "b", "b");
	serv.adaugare_service("a", "b", "a", "a");
	vec = serv.sortare(MasinaService::cmpnrinmat);
	assert(vec[0].getNrInmat() == "a");
	vec = serv.sortare(MasinaService::cmpprod);
	assert(vec[0].getNrInmat() == "b");
	vec = serv.sortare(MasinaService::cmptipmodel);
	assert(vec[0].getNrInmat() == "a");
}
void testAll() 
{
	test_domain();
	test_add();
	test_stergere();
	test_modificare();
	test_Undo();
	test_sortare();
}