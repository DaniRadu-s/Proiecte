#pragma once
#include "QWidget"
#include "QAbstractTableModel"
#include "service.h"
#include "Masina.h"

class MyTableModel : public QAbstractTableModel {
    Q_OBJECT

        vector<Masina>& elems;
public:
    MyTableModel(vector<Masina>& e)
        : elems(e) {}

    int rowCount(const QModelIndex& parent = QModelIndex()) const override {
        return elems.size();
    }

    int columnCount(const QModelIndex& parent = QModelIndex()) const override {
        return 4;
    }

    QVariant data(const QModelIndex& index, int role = Qt::DisplayRole) const override {
        if (role == Qt::DisplayRole) {
            Masina o = elems[index.row()];
            vector<QString> ats = { QString::fromStdString(o.getNrInmat()),
                                   QString::fromStdString(o.getProd()),
                                   QString::fromStdString(o.getModel()),
                                   QString::fromStdString(o.getTip()) };

            return ats[index.column()];
        }
        return {};
    }

public:
    void setElems(vector<Masina>& e) {
        elems = e;
        emit layoutChanged();
    };

};