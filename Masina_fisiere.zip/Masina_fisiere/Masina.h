#pragma once

#include <QtWidgets/QWidget>
#include "service.h"
#include <QTWidgets/qlabel.h>
#include <QTWidgets/qlayout.h>
#include <QTWidgets/qpushbutton.h>
#include <QTWidgets/qlineedit.h>
#include <QTWidgets/qlistwidget.h>
#include <QTWidgets/qformlayout.h>
#include <QTWidgets/qmessagebox.h>
#include <QTWidgets/qtablewidget.h>
#include <QTWidgets/qlineedit.h>
#include <QtWidgets/qformlayout.h>
#include "ListModel.h"
#include <QString>
#include <string>
#include "draw.h"

class SecondWindow : public QWidget {
    Q_OBJECT
private:
    MasinaService& serv;
    QHBoxLayout* layout = new QHBoxLayout;
    QFormLayout* sly = new QFormLayout;
    QLineEdit* dupa = new QLineEdit;
    QLineEdit* fil = new QLineEdit;
    QPushButton* btnok = new QPushButton{ "Ok" };
    QPushButton* btnext = new QPushButton{ "Iesire" };
    QListWidget* lst = new QListWidget;
public:
    SecondWindow(MasinaService& srv);
    void init1() {
        layout->addWidget(lst);
        sly->addRow("Introduceti dupa ce doriti sa filtrati: ", fil);
        sly->addRow("Ce tip/model?", dupa);
        setLayout(layout);
        sly->addWidget(btnok);
        sly->addWidget(btnext);
        layout->addLayout(sly);
    }
    void init1_connect() {
        QObject::connect(btnext, &QPushButton::clicked, [&]() {
            QMessageBox::information(nullptr, "Info", "Exit apasat!");
            close();
            });
        QObject::connect(btnok, &QPushButton::clicked, [&]() {
            QString d = dupa->text();
            QString f = fil->text();
            if (f.toStdString() == "tip")
                loaddata1(serv.filtrare(MasinaService::tip, d.toStdString()));
            if (f.toStdString() == "model")
                loaddata1(serv.filtrare(MasinaService::model, d.toStdString()));
            dupa->clear();
            fil->clear();
            });
    }
    void loaddata1(const std::vector<Masina>& vec) {
        lst->clear();
        for (auto& it : vec) {
            QString itemText = QString::fromStdString(
                "Nr inmat: " + it.getNrInmat() + "; " +
                "Prod: " + it.getProd() + "; " +
                "Model: " + it.getModel() + "; " +
                "Tip: " + it.getTip()
            );
            lst->addItem(itemText);
        }
    }
};

class Table : public QWidget
{
    Q_OBJECT

public:
    Table(MasinaService& srv);

private:
    MasinaService& serv;
    QHBoxLayout* mainly = new QHBoxLayout;
    QFormLayout* buttonly = new QFormLayout;
    QHBoxLayout* formly = new QHBoxLayout;
    QHBoxLayout* filt = new QHBoxLayout;
    QLineEdit* nr = new QLineEdit;
    QLineEdit* pr = new QLineEdit;
    QLineEdit* m = new QLineEdit;
    QLineEdit* t = new QLineEdit;
    QLineEdit* nr2 = new QLineEdit;
    QLineEdit* sort = new QLineEdit;
    QTableWidget* list = new QTableWidget;
    QPushButton* btnadd = new QPushButton{ "Adauga" };
    QPushButton* btndel = new QPushButton{ "Sterge" };
    QPushButton* btnmod = new QPushButton{ "Modifica" };
    QPushButton* btnund = new QPushButton{ "Undo" };
    QPushButton* btnsort = new QPushButton{ "Sorteaza" };
    QPushButton* btnfil = new QPushButton{ "Filtreaza" };
    QPushButton* btnexit = new QPushButton{ "Iesire" };
    void init() {
        setLayout(mainly);
        mainly->addWidget(list);
        buttonly->addRow("Numar de inmatriculare: ", nr);
        buttonly->addRow("Producator: ", pr);
        buttonly->addRow("Model: ", m);
        buttonly->addRow("Tip: ", t);
        buttonly->addRow("Numarul de inmatriculare al masinii de sters/modificat: ", nr2);
        buttonly->addRow("Introducaeti dupa ce doriti sa sortati: ", sort);
        mainly->addLayout(buttonly);
        formly->addWidget(btnadd);
        formly->addWidget(btndel);
        formly->addWidget(btnmod);
        formly->addWidget(btnund);
        formly->addWidget(btnsort);
        formly->addWidget(btnfil);
        formly->addWidget(btnexit);
        buttonly->addRow(formly);
    }
    void init_connect() {
        QObject::connect(btnexit, &QPushButton::clicked, [&]() {
            QMessageBox::information(nullptr, "Info", "Exit apasat!");
            loaddata1(serv.getAllservice());
            close();
            });
        QObject::connect(btnadd, &QPushButton::clicked, [&]() {
            QString nr1 = nr->text();
            QString pr1 = pr->text();
            QString m1 = m->text();
            QString t1 = t->text();
            if (nr1.toStdString() != "" && pr1.toStdString() != "" && m1.toStdString() != "" && t1.toStdString() != "")
                try {
                serv.adaugare_service(nr1.toStdString(), pr1.toStdString(), m1.toStdString(), t1.toStdString());
                QMessageBox::information(nullptr, "Info", "Adaugare cu succes!");
                loaddata1(serv.getAllservice());
            }
            catch (const exception e)
            {
                QString str = QString::fromStdString(e.what());
                QMessageBox::information(nullptr, "Info", str);
            }
            nr->clear();
            pr->clear();
            m->clear();
            t->clear();
            });
        QObject::connect(btndel, &QPushButton::clicked, [&]() {
            QString nr1 = nr2->text();
            try {
                serv.stergere_service(nr1.toStdString());
                QMessageBox::information(nullptr, "Info", "Stergere cu succes!");
                loaddata1(serv.getAllservice());
            }
            catch (const exception e)
            {
                QString str = QString::fromStdString(e.what());
                QMessageBox::information(nullptr, "Info", str);
            }
            nr2->clear();
            });
        QObject::connect(btnmod, &QPushButton::clicked, [&]() {
            QString nr3 = nr2->text();
            QString nr1 = nr->text();
            QString pr1 = pr->text();
            QString m1 = m->text();
            QString t1 = t->text();

            try {
                serv.modificare_service(nr3.toStdString(), nr1.toStdString(), pr1.toStdString(), m1.toStdString(), t1.toStdString());
                QMessageBox::information(nullptr, "Info", "Modificare cu succes!");
                loaddata1(serv.getAllservice());
            }
            catch (const exception e)
            {
                QString str = QString::fromStdString(e.what());
                QMessageBox::information(nullptr, "Info", str);
            }
            nr2->clear();
            nr->clear();
            pr->clear();
            m->clear();
            t->clear();
            });
        QObject::connect(btnund, &QPushButton::clicked, [&]() {
            try {
                serv.Undo();
                QMessageBox::information(nullptr, "Info", "Undo efectuat cu succes!");
                loaddata1(serv.getAllservice());
            }
            catch (const exception e)
            {
                QString str = QString::fromStdString(e.what());
                QMessageBox::information(nullptr, "Info", str);
            }
            });
        QObject::connect(btnsort, &QPushButton::clicked, [&]() {
            QString nr1 = sort->text();
            if (nr1 == "nrinmat")
                loaddata1(serv.sortare(MasinaService::cmpnrinmat));
            if (nr1 == "prod")
                loaddata1(serv.sortare(MasinaService::cmpprod));
            if (nr1 == "modeltip")
                loaddata1(serv.sortare(MasinaService::cmptipmodel));
            QMessageBox::information(nullptr, "Info", "Sortare efectuata cu succes!");
            sort->clear();
            });
        QObject::connect(btnfil, &QPushButton::clicked, [&]() {
            SecondWindow* neww = new SecondWindow(serv);
            neww->show();
            });
    }
    void loaddata1(const std::vector<Masina>& vec) {
        list->clear();
        int row = 0;
        list->setColumnCount(4);
        list->setRowCount(serv.getAllservice().size());
        QStringList headers;
        headers << "Numar de inmatriculare" << "Producator" << "Model" << "Tip";
        list->setHorizontalHeaderLabels(headers);
        for (auto& it : vec)
        {
            auto* item1 = new QTableWidgetItem(QString::fromStdString(it.getNrInmat()));
            auto* item2 = new QTableWidgetItem(QString::fromStdString(it.getProd()));
            auto* item3 = new QTableWidgetItem(QString::fromStdString(it.getModel()));
            auto* item4 = new QTableWidgetItem(QString::fromStdString(it.getTip()));
            list->setItem(row, 0, item1);
            list->setItem(row, 1, item2);
            list->setItem(row, 2, item3);
            list->setItem(row, 3, item4);
            row++;
        }
    }
};

class QCos : public QWidget, public Observer
{
    Q_OBJECT
public:
    QCos(MasinaService& srv);
    ~QCos();
    void updateObserver() override {
        loaddatacos();
    }
    void loaddatacos()
    {
        listModel->setMasini(serv.getCos_s());
        listcos->clear();
        for (auto& it : serv.getCos_s()) {
            QFont font;
            font.setBold(true);
            QString itemText = QString::fromStdString(
                "Nr inmat: " + it.getNrInmat() + "; " +
                "Prod: " + it.getProd() + "; " +
                "Model: " + it.getModel() + "; " +
                "Tip: " + it.getTip()
            );
            QListWidgetItem* s = new QListWidgetItem(itemText);
            s->setFont(font);
            listcos->addItem(s);
        }
    }
private:
    MasinaService& serv;
    ListModel* listModel = new ListModel{serv.getCos_s()};
    QLineEdit* name = new QLineEdit;
    QListWidget* listcos = new QListWidget;
    QLineEdit* nr = new QLineEdit;
    QHBoxLayout* mainly = new QHBoxLayout;
    QTableView* qlv = new QTableView;
    QPushButton* btnadc = new QPushButton{ "Adauga in cos" };
    QPushButton* btngol = new QPushButton{ "Golire cos" };
    QPushButton* btnrnd = new QPushButton{ "Generare cos" };
    void init_cos()
    {
        setLayout(mainly);
        auto formLy = new QFormLayout;
        qlv->setModel(listModel);
        mainly->addWidget(qlv);
        mainly->addLayout(formLy);
        formLy->addRow("Nume pentru adaugare", name);
        formLy->addRow("Numar pentru generare", nr);
        mainly->addWidget(listcos);
        mainly->addWidget(btnadc);
        mainly->addWidget(btngol);
        mainly->addWidget(btnrnd);

    }
    void init_connect_cos()
    {
        QObject::connect(btnadc, &QPushButton::clicked, [&]() {
            if (name->text().isEmpty()) { return 1; }
            auto n = name->text().toStdString();
            serv.adaugare_cos_s(serv.cautare(n));
            });
           
        QObject::connect(btngol, &QPushButton::clicked, [&]() {
            serv.golire_s();
            });
        QObject::connect(btnrnd, &QPushButton::clicked, [&]() {
            if (nr->text().isEmpty()) { return 1; }
            auto n = nr->text().toInt();
            serv.generare_s(n, serv.getAllservice());
            });
    }


};

class GUI : public QWidget
{
    Q_OBJECT

public:
    GUI(MasinaService& srv);
    ~GUI();
    void loaddata(const std::vector<Masina>& vec) {
        list->clear();
        for (auto& it : vec) {
            QFont font;
            font.setBold(true);
            QString itemText = QString::fromStdString(
                "Nr inmat: " + it.getNrInmat() + "; " +
                "Prod: " + it.getProd() + "; " +
                "Model: " + it.getModel() + "; " +
                "Tip: " + it.getTip()
            );
            QListWidgetItem* s = new QListWidgetItem(itemText);
            s->setFont(font);
            list->addItem(s);
        }
    }
    void loaddatarnd()
    {
        listcos->clear();
        for (auto& it : serv.getCos_s()) {
            QFont font;
            font.setBold(true);
            QString itemText = QString::fromStdString(
                "Nr inmat: " + it.getNrInmat() + "; " +
                "Prod: " + it.getProd() + "; " +
                "Model: " + it.getModel() + "; " +
                "Tip: " + it.getTip()
            );
            QListWidgetItem* s = new QListWidgetItem(itemText);
            s->setFont(font);
            listcos->addItem(s);
        }
    }
private:
    MasinaService& serv;
    QHBoxLayout* mainly = new QHBoxLayout;
    QFormLayout* buttonly = new QFormLayout;
    QHBoxLayout* formly = new QHBoxLayout;
    QHBoxLayout* filt = new QHBoxLayout;
    QLineEdit* nr = new QLineEdit;
    QLineEdit* pr = new QLineEdit;
    QLineEdit* m = new QLineEdit;
    QLineEdit* t = new QLineEdit;
    QLineEdit* nr2 = new QLineEdit;
    QLineEdit* sort = new QLineEdit;
    QListWidget* list = new QListWidget;
    QLabel* lbl = new QLabel{ "Cos" };
    QLabel* lbl1 = new QLabel{ "Lista" };
    QVBoxLayout* lly = new QVBoxLayout;
    QVBoxLayout* cly = new QVBoxLayout;
    QListWidget* listcos = new QListWidget;
    QLineEdit* ln = new QLineEdit;
    QPushButton* btndrw = new QPushButton{ "Deseneaza cos" };
    QPushButton* btntbl = new QPushButton{ "Tabel" };
    QPushButton* btnrnd = new QPushButton{ "Generare cos" };
    QPushButton* btnadc = new QPushButton{ "Adauga in cos" };
    QPushButton* btncos = new QPushButton{ "Cos" };
    QPushButton* btnadd = new QPushButton{ "Adauga" };
    QPushButton* btndel = new QPushButton{ "Sterge" };
    QPushButton* btngol = new QPushButton{ "Golire cos" };
    QPushButton* btnmod = new QPushButton{ "Modifica" };
    QPushButton* btnund = new QPushButton{ "Undo" };
    QPushButton* btnsort = new QPushButton{ "Sorteaza" };
    QPushButton* btnfil = new QPushButton{ "Filtreaza" };
    QPushButton* btnexit = new QPushButton{ "Iesire" };
    void init() {
        setLayout(mainly);
        lly->addWidget(lbl1);
        lly->addWidget(list);
        //cly->addWidget(lbl);
        //cly->addWidget(listcos);
        mainly->addLayout(lly);
        mainly->addLayout(cly);
        buttonly->addRow("Numar de inmatriculare: ", nr);
        buttonly->addRow("Producator: ", pr);
        buttonly->addRow("Model: ", m);
        buttonly->addRow("Tip: ", t);
        buttonly->addRow("Numarul de inmatriculare al masinii de sters/modificat: ", nr2);
        buttonly->addRow("Introduceti dupa ce doriti sa sortati: ", sort);
        buttonly->addRow("Introduceti numarul de masini pentru generare in cos: ", ln);
        mainly->addLayout(buttonly);
        formly->addWidget(btncos);
        formly->addWidget(btndrw);
        formly->addWidget(btnadd);
        formly->addWidget(btndel);
        formly->addWidget(btnmod);
        formly->addWidget(btnund);
        formly->addWidget(btnsort);
        formly->addWidget(btnfil);
        formly->addWidget(btntbl);
        formly->addWidget(btnexit);
        buttonly->addRow(formly);
    }
    void init_connect() {
        QObject::connect(btnexit, &QPushButton::clicked, [&]() {
            QMessageBox::information(nullptr, "Info", "Exit apasat!");
            close();
            });
        QObject::connect(btndrw, &QPushButton::clicked, [&]() {
            CirclesWindow* cir = new CirclesWindow{ serv };
            cir->show();
            serv.addObserver(cir);
            });
        QObject::connect(btncos, &QPushButton::clicked, [&]() {
            QCos* co = new QCos{ serv };
            co->show();
            serv.addObserver(co);
            });
        QObject::connect(btnadd, &QPushButton::clicked, [&]() {
            QString nr1 = nr->text();
            QString pr1 = pr->text();
            QString m1 = m->text();
            QString t1 = t->text();
            if (nr1.toStdString() != "" && pr1.toStdString() != "" && m1.toStdString() != "" && t1.toStdString() != "")
                try {
                serv.adaugare_service(nr1.toStdString(), pr1.toStdString(), m1.toStdString(), t1.toStdString());
                QMessageBox::information(nullptr, "Info", "Adaugare cu suuces!");
                loaddata(serv.getAllservice());
            }
            catch (const exception e)
            {
                QString str = QString::fromStdString(e.what());
                QMessageBox::information(nullptr, "Info", str);
            }
            nr->clear();
            pr->clear();
            m->clear();
            t->clear();
            });
        QObject::connect(btntbl, &QPushButton::clicked, [&]() {
            Table* tab = new Table{ serv };
            tab->show();
            loaddata(serv.getAllservice());
            });
        QObject::connect(btndel, &QPushButton::clicked, [&]() {
            QString nr1 = nr2->text();
            try {
                serv.stergere_service(nr1.toStdString());
                QMessageBox::information(nullptr, "Info", "Stergere cu succes!");
                loaddata(serv.getAllservice());
            }
            catch (const exception e)
            {
                QString str = QString::fromStdString(e.what());
                QMessageBox::information(nullptr, "Info", str);
            }
            nr2->clear();
            });
        QObject::connect(btnmod, &QPushButton::clicked, [&]() {
            QString nr3 = nr2->text();
            QString nr1 = nr->text();
            QString pr1 = pr->text();
            QString m1 = m->text();
            QString t1 = t->text();

            try {
                serv.modificare_service(nr3.toStdString(), nr1.toStdString(), pr1.toStdString(), m1.toStdString(), t1.toStdString());
                QMessageBox::information(nullptr, "Info", "Modificare cu succes!");
                loaddata(serv.getAllservice());
            }
            catch (const exception e)
            {
                QString str = QString::fromStdString(e.what());
                QMessageBox::information(nullptr, "Info", str);
            }
            nr2->clear();
            nr->clear();
            pr->clear();
            m->clear();
            t->clear();
            });
        QObject::connect(btnund, &QPushButton::clicked, [&]() {
            try {
                serv.Undo();
                QMessageBox::information(nullptr, "Info", "Undo efectuat cu succes!");
                loaddata(serv.getAllservice());
            }
            catch (const exception e)
            {
                QString str = QString::fromStdString(e.what());
                QMessageBox::information(nullptr, "Info", str);
            }
            });
        QObject::connect(btnsort, &QPushButton::clicked, [&]() {
            QString nr1 = sort->text();
            if (nr1 == "nrinmat")
                loaddata(serv.sortare(MasinaService::cmpnrinmat));
            if (nr1 == "prod")
                loaddata(serv.sortare(MasinaService::cmpprod));
            if (nr1 == "modeltip")
                loaddata(serv.sortare(MasinaService::cmptipmodel));
            QMessageBox::information(nullptr, "Info", "Sortare efectuata cu succes!");
            sort->clear();
            });
        QObject::connect(btnfil, &QPushButton::clicked, [&]() {
            SecondWindow* neww = new SecondWindow(serv);
            neww->show();
            });
    }
};
