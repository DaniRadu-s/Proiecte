#include "service.h"
void MasinaService::adaugare_cos_s(Masina mas)
{
	cos.adaugare_cos(mas);
	notify();
}
void MasinaService::golire_s()
{
	cos.golire();
	notify();
}
vector<Masina>&MasinaService::getCos_s()
{	
	return cos.getCos();
}
void MasinaService::generare_s(int n, vector<Masina> l)
{	
	golire_s();
	cos.generare_random(n, l);
	notify();
}
void MasinaService::adaugare_service(const string& nrinmat, const string& prod, const string& model, const string& tip) {
	Masina mas = { nrinmat ,prod,model,tip };
	repo.adaugare_repo(mas);
	UndoActiune.push_back(make_unique<UndoAdaugare>(repo, mas));
}

void MasinaService::stergere_service(const string& nrinmat) {
	Masina x = { "","","","" };
	for (Masina it : repo.getAll())
	{
		if (it.getNrInmat() == nrinmat) {
			x = it; break;
		}
	}
	repo.stergere_repo(nrinmat);
	UndoActiune.push_back(make_unique<UndoStergere>(repo, x));
}

void MasinaService::modificare_service(const string& nrinmatvechi, const string& nrinmatnou, const string& prod, const string& model, const string& tip) {
	Masina x = { "","","","" };
	for (Masina it : repo.getAll())
		if (it.getNrInmat() == nrinmatvechi) {
			x = it; break;
		}
	repo.modificare_repo(nrinmatvechi, nrinmatnou, prod, model, tip);
	UndoActiune.push_back(make_unique<UndoModificare>(repo, nrinmatnou, nrinmatvechi, x.getProd(), x.getModel(), x.getTip()));
}

bool MasinaService::cmpnrinmat(const Masina& a, const Masina& b) {
	if (a.getNrInmat() > b.getNrInmat())
		return true;
	return false;
}

bool MasinaService::cmpprod(const Masina& a, const Masina& b) {
	if (a.getProd() > b.getProd())
		return true;
	return false;
}

bool MasinaService::cmptipmodel(const Masina& a, const Masina& b) {
	if (a.getModel() > b.getModel() || a.getModel() == b.getModel() && a.getTip() > b.getTip())
		return true;
	return false;
}

bool MasinaService::tip(const Masina& a, const string& type) {
	return a.getTip() == type;
}

bool MasinaService::model(const Masina& a, const string& model) {
	return a.getModel() == model;
}

Masina MasinaService::cautare(string nrinmat)
{
	auto it = std::find_if(getAllservice().begin(), getAllservice().end(), [&](const Masina& m) {
		return m.getNrInmat() == nrinmat;});
	return*(it);
}

vector<Masina> MasinaService::filtrare(bool functie(const Masina&, const string&), const string& str) {
	vector<Masina> vec;
	for (auto& it : repo.getAll())
		if (functie(it, str)) vec.push_back(it);
	return vec;
}


vector<Masina> MasinaService::sortare(bool functie(const Masina&, const Masina&)) {
	Masina aux = { "","","","" };
	vector<Masina> vec = repo.getAll();
	for (int i = 0;i < vec.size() - 1;i++)
		for (int j = i + 1;j < vec.size();j++)
			if (functie(vec[i], vec[j]))
			{
				aux = vec[i];
				vec[i] = vec[j];
				vec[j] = aux;
			}
	return vec;
}

void MasinaService::Undo() {
	if (UndoActiune.empty())
		throw exception("Nu se mai poate face Undo.\n");
	UndoActiune.back()->doUndo();
	UndoActiune.pop_back();
}
const vector<Masina>& MasinaService::getAllservice() noexcept {
	return repo.getAll();
}