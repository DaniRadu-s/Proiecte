#pragma once
#include "repository.h"
class Undo {
public:
	virtual void doUndo() = 0;
	virtual ~Undo()=default;
};

class UndoAdaugare :public Undo {
private:
	RepoAbstract& repo;
	Masina masinaadaugata;
public:
	UndoAdaugare(RepoAbstract& rep, Masina m) :repo{ rep }, masinaadaugata{ m } {}
	void doUndo() override {
		repo.stergere_repo(masinaadaugata.getNrInmat());
	}
};

class UndoStergere :public Undo {
private:
	RepoAbstract& repo;
	Masina masinastearsa;
public:
	UndoStergere(RepoAbstract& rep, Masina m) :repo{ rep }, masinastearsa{ m } {}
	void doUndo() override {
		repo.adaugare_repo(masinastearsa);
	}
};

class UndoModificare :public Undo {
private:
	RepoAbstract& repo;
	string nrinmatvechi;
	string nrinmatnou;
	string prod;
	string model;
	string tip;
public:
	UndoModificare(RepoAbstract& rep, string nr1, string nr, string m, string p, string t) :repo{ rep }, nrinmatnou{nr1}, nrinmatvechi { nr }, prod{ p }, model{ m }, tip{ t } {}
	void doUndo() override {
		repo.modificare_repo(nrinmatnou, nrinmatvechi, prod, model, tip);
	}
};
