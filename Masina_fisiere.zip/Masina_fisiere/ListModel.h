#pragma once
#include <QAbstractListModel>
#include <string>
#include <vector>

#include "domain.h"

using namespace std;

class ListModel : public QAbstractListModel {
    vector<Masina> masini;
public:
    ListModel(const vector<Masina>& masini) : masini{ masini } {}

    int rowCount(const QModelIndex& parent) const override {
        return masini.size();
    }

    int columnCount(const QModelIndex& parent = QModelIndex()) const override {
        return 4;
    }

    QVariant data(const QModelIndex& index, int role) const override {
        if (!index.isValid() || index.row() >= masini.size())
            return QVariant();

        if (role == Qt::DisplayRole) {
            Masina a = masini.at(index.row());
            if (index.column() == 0)
                return QString::fromStdString(a.getNrInmat());
            if (index.column() == 1)
                return QString::fromStdString(a.getProd());
            if (index.column() == 2)
                return QString::fromStdString(a.getModel());
            if (index.column() == 3)
                return QString::fromStdString(a.getTip());
        }

        return QVariant();
    }

    void setMasini(const vector<Masina>& masini) {
        this->masini = masini;
        auto topLeft = createIndex(0, 0);
        int x = masini.size();
        auto bottomRight = createIndex(x, 4);
        emit dataChanged(topLeft, bottomRight);
        emit layoutChanged();
    }
};
