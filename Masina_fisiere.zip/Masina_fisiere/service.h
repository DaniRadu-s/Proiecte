#pragma once
#include "repository.h"
#include "Undo.h"
#include <memory>
#include "observer.h"
class MasinaService:public Observable {
private:
	Cos& cos;
	RepoAbstract& repo;
	vector<unique_ptr<Undo>> UndoActiune;
public:
	MasinaService(RepoAbstract& rep, Cos& c) : repo{ rep }, cos{ c } {}
	void adaugare_cos_s(Masina mas);
	void golire_s();
	vector<Masina>&getCos_s();
	void generare_s(int n, vector<Masina> l);
	void adaugare_service(const string& nrinmat, const string& prod, const string& model, const string& tip);
	void stergere_service(const string& nrinmat);
	void modificare_service(const string& nrinmatvechi, const string& nrinmatnou, const string& prod, const string& model, const string& tip);
	void Undo();
	static bool cmpnrinmat(const Masina& a, const Masina& b);
	static bool cmpprod(const Masina& a, const Masina& b);
	static bool cmptipmodel(const Masina& a, const Masina& b);
	vector<Masina> sortare(bool functie(const Masina&, const Masina&));
	static bool tip(const Masina& a, const string& str);
	static bool model(const Masina& a, const string& str);
	Masina cautare(string nrinmat);
	vector<Masina> filtrare(bool functie(const Masina&, const string&), const string& str);
	const vector<Masina>& getAllservice() noexcept;
};