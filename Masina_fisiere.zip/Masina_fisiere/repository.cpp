#include "repository.h"
#include <iostream>
void MasinaRepo::adaugare_repo(Masina mas) {
	for (auto& it : masini)
		if (mas.getNrInmat() == it.getNrInmat())
			throw exception("Masina exista deja.\n");
	masini.push_back(mas);
}

void Repofile::adaugare_repo(Masina mas) {
	MasinaRepo::adaugare_repo(mas);
	save_to_file();
}

void MasinaRepo::stergere_repo(const string& nrinmat) {
	auto it = std::find_if(masini.begin(), masini.end(), [&nrinmat](const Masina& m) {
		return m.getNrInmat() == nrinmat;
		});

	if (it != masini.end()) {
		masini.erase(it);
	}
	else {
		throw exception("Masina nu exista.\n");
	}
}

void Repofile::stergere_repo(const string& nrinmat) {
	MasinaRepo::stergere_repo(nrinmat);
	save_to_file();
}

void MasinaRepo::modificare_repo(const string& nrinmatvechi, const string& nrinmatnou, const string& prod, const string& model, const string& tip) {
	int ok = 0;
	for(auto&it:masini)
		if (it.getNrInmat() == nrinmatvechi)
		{
			it.setNrInmat(nrinmatnou);
			it.setModel(model);
			it.setProd(prod);
			it.setTip(tip);
			ok = 1;
		}
	if (!ok) throw exception("Masina nu exista.\n");
}

void Repofile::modificare_repo(const string& nrinmatvechi, const string& nrinmatnou, const string& prod, const string& model, const string& tip) {
	MasinaRepo::modificare_repo(nrinmatvechi, nrinmatnou, prod, model, tip);
	save_to_file();
}

vector<Masina>& MasinaRepo::getAll() noexcept{
	return masini;
}

void Repofile::load_from_file() {
	ifstream f(filename);
	if (!f.is_open())
		throw exception();
	string line;
	while (getline(f,line)) {
		istringstream iss(line);
		string nr, p, m, t;
		if(getline(iss,nr,' ') && getline(iss, p, ' ') && getline(iss, m, ' ') && getline(iss, t, ' '))
			MasinaRepo::adaugare_repo(Masina { nr, p, m, t });
	}
	f.close();
}

void Repofile::save_to_file() {
	ofstream g(filename);
	if (!g.is_open())
		throw exception();
	for (auto& it : getAll()) {
		g << it.getNrInmat() << " " << it.getProd() << " " << it.getModel() << " " << it.getTip()<<"\n";
	}
	g.close();
}

void Cos::adaugare_cos(Masina mas)
{
	masinicos.push_back(mas);
}

void Cos::golire()
{
	masinicos.clear();
}

void Cos::generare_random(int n, vector<Masina> l)
{
	auto s = chrono::system_clock::now().time_since_epoch().count();
	shuffle(l.begin(), l.end(), default_random_engine(s));
	for (int i = 0;i < n &&  !l.empty();i++)
	{
		masinicos.push_back(l.back());
		l.pop_back();
	}
}

vector<Masina>&Cos::getCos()
{
	return masinicos;
}
