#pragma once

#include <QtWidgets/QWidget>
#include "ui_taskk.h"
#include "serv.h"
#include "qtablewidget.h"
#include "qlayout.h"
#include "qformlayout.h";
#include "qpushbutton.h"
#include "qlineedit.h"
#include "qmessagebox.h"

class SecondWd : public QWidget , public Observer {
    Q_OBJECT
private:
    ServTask& serv;
    string str;
    QTableWidget* tl = new QTableWidget;
    QHBoxLayout* mainl = new QHBoxLayout;
    QFormLayout* sl = new QFormLayout;
    QPushButton* op = new QPushButton{ "Opened" };
    QPushButton* in = new QPushButton{ "Inprogress" };
    QPushButton* cl = new QPushButton{ "Closed" };
public:
    SecondWd(ServTask& s, string st);
    ~SecondWd();
    void update() override {
        loaddata(serv.getAllService(), str);
    }
    void init() {
        setWindowTitle(QString::fromStdString(str));
        setLayout(mainl);
        tl->setColumnCount(4);
        tl->setRowCount(serv.getAllService().size());
        mainl->addWidget(tl);
        mainl->addLayout(sl);
        sl->addWidget(op);
        sl->addWidget(in);
        sl->addWidget(cl);
        loaddata(serv.getAllService(), str);
    }
    void fct() {
        int index = tl->selectionModel()->currentIndex().row();
        vector<Task> vec = serv.getAllService();
        vector<Task> vec2;
        copy_if(vec.begin(), vec.end(), back_inserter(vec2), [&](Task t1) {
            return t1.getstare() == str;
            });
        qDebug()<< vec2.size();
        Task t = vec2[index];
        serv.update_s(t.getid(), t.getdescr(), "opened", t.getprogramatori());
        serv.notify();
    }
    void fct1() {
        int index = tl->selectionModel()->currentIndex().row();
        vector<Task> vec = serv.getAllService();
        vector<Task> vec2;
        copy_if(vec.begin(), vec.end(), back_inserter(vec2), [&](Task t1) {
            return t1.getstare() == str;
            });
        qDebug() << vec2.size();
        Task t = vec2[index];
        serv.update_s(t.getid(), t.getdescr(), "closed", t.getprogramatori());
        serv.notify();
    }
    void fct2() {
        int index = tl->selectionModel()->currentIndex().row();
        vector<Task> vec = serv.getAllService();
        vector<Task> vec2;
        copy_if(vec.begin(), vec.end(), back_inserter(vec2), [&](Task t1) {
            return t1.getstare() == str;
            });
        qDebug() << vec2.size();
        Task t = vec2[index];
        serv.update_s(t.getid(), t.getdescr(), "inprogress", t.getprogramatori());
        serv.notify();
    }
    void init_connect() {
        QObject::connect(op, &QPushButton::clicked, this, &SecondWd::fct);
        QObject::connect(cl, &QPushButton::clicked, this, &SecondWd::fct1);
        QObject::connect(in, &QPushButton::clicked, this, &SecondWd::fct2);
    }
    void loaddata(vector<Task> vec, string s) {
        tl->clear();
        int row = 0;
        for (auto& it : vec)
        {
            if (it.getstare() == s)
            {
                auto* item1 = new QTableWidgetItem(QString::number(it.getid()));
                auto* item2 = new QTableWidgetItem(QString::fromStdString(it.getdescr()));
                auto* item3 = new QTableWidgetItem(QString::fromStdString(it.getstare()));
                auto* item4 = new QTableWidgetItem(QString::number(it.getprogramatori().size()));
                tl->setItem(row, 0, item1);
                tl->setItem(row, 1, item2);
                tl->setItem(row, 2, item3);
                tl->setItem(row, 3, item4);
                row++;
            }
        }
    }
};


class taskk : public QWidget
{
    Q_OBJECT

public:
    taskk(ServTask& s);
    ~taskk();
    void init() {
        SecondWd* s1 = new SecondWd{ serv,"opened"};
        SecondWd* s2 = new SecondWd{ serv,"closed" };
        SecondWd* s3 = new SecondWd{ serv,"inprogress" };
        s1->show();
        s2->show();
        s3->show();
        setLayout(mainly);
        tbl->setColumnCount(4);
        tbl->setRowCount(serv.getAllService().size());
        mainly->addWidget(tbl);
        mainly->addLayout(sly);
        sly->addRow("Adaugare", add);
        sly->addRow("Id", ln1);
        sly->addRow("Descriere", ln2);
        sly->addRow("Stare", ln3);
        sly->addRow("Programatori", ln4);
        sly->addRow("Nume Programator", ln5);
        sly->addRow("Cautare", cc);
        sly->addRow("Revenire", bk);
        loaddata(serv.getAllService());
    }
    void fct() {
        int id = ln1->text().toInt();
        string d = ln2->text().toStdString();
        string s = ln3->text().toStdString();
        string p = ln4->text().toStdString();
        vector<string> prog_list;
        istringstream prog_stream(p);
        string prog;
        while (getline(prog_stream, prog, ',')) {
            prog_list.push_back(prog);
        }
        try
        {
            serv.adaugare_s(id, d, s, prog_list);
        }
        catch (exception& e)
        {
            QMessageBox::warning(nullptr, QString::fromStdString("Info"), QString::fromStdString(e.what()));
        }
        loaddata(serv.getAllService());
        serv.notify();
    }
    void fct1() {
        string nume = ln5->text().toStdString();
        vector<Task> v;
        for(auto&it:serv.getAllService())
            for(auto&it1:it.getprogramatori())
                if (it1 == nume)
                {
                    v.push_back(it);
                    break;
                }
        loaddata(v);
    }
    void fct2() {
        loaddata(serv.getAllService());
    }
    void init_connect() {
        QObject::connect(add, &QPushButton::clicked, this, &taskk::fct);
        QObject::connect(cc, &QPushButton::clicked, this, &taskk::fct1);
        QObject::connect(bk, &QPushButton::clicked, this, &taskk::fct2);
    }
    void loaddata(vector<Task> vec) {
        tbl->clear();
        int row=0;
        for (auto& it : vec)
        {
            auto* item1 = new QTableWidgetItem(QString::number(it.getid()));
            auto* item2 = new QTableWidgetItem(QString::fromStdString(it.getdescr()));
            auto* item3 = new QTableWidgetItem(QString::fromStdString(it.getstare()));
            auto* item4 = new QTableWidgetItem(QString::number(it.getprogramatori().size()));
            tbl->setItem(row, 0, item1);
            tbl->setItem(row, 1, item2);
            tbl->setItem(row, 2, item3);
            tbl->setItem(row, 3, item4);
            row++;
        }

    }

private:
    ServTask& serv;
    QTableWidget* tbl = new QTableWidget;
    QHBoxLayout* mainly = new QHBoxLayout;
    QFormLayout* sly = new QFormLayout;
    QPushButton* add = new QPushButton{ "Add" };
    QPushButton* cc = new QPushButton{ "Cautare" };
    QPushButton* bk = new QPushButton{ "Back" };
    QLineEdit* ln1 = new QLineEdit;
    QLineEdit* ln2 = new QLineEdit;
    QLineEdit* ln3 = new QLineEdit;
    QLineEdit* ln4 = new QLineEdit;
    QLineEdit* ln5 = new QLineEdit;
};
