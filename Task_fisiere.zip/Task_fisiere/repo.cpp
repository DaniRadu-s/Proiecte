#include "repo.h"

void RepoTask::load_from_file()
{
    ifstream f(filename);
    if (!f.is_open())
        throw exception();
    string line;
    while (getline(f, line)) {
        istringstream iss(line);
        string id, descr, stare, programatori;
        if (getline(iss, id, ';') && getline(iss, descr, ';') && getline(iss, stare, ';') && getline(iss, programatori)) {
            vector<string> prog_list;
            istringstream prog_stream(programatori);
            string prog;
            while (getline(prog_stream, prog, ',')) {
                prog_list.push_back(prog);
            }
            tasks.push_back(Task{ stoi(id), descr, stare, prog_list });
        }
    }
    f.close();
}

vector<Task> RepoTask::getAll()
{
    return tasks;
}

void RepoTask::adaugare(Task t)
{
    int ok = 0;
    for (auto& it : tasks)
        if (it.getid() == t.getid()) ok = 1;
    if (ok == 0 && !t.getdescr().empty() && t.getprogramatori().size() >= 1 && t.getprogramatori().size() <= 4 &&
        (t.getstare() == "closed" || t.getstare() == "inprogress" || t.getstare() == "opened"))
    {
        tasks.push_back(t);
        save_to_file();
    }
    else throw exception("Nu este un task valid!");
}

void RepoTask::save_to_file()
{
    ofstream g(filename);
    if (!g.is_open())
        throw exception();
    for (auto& it : tasks)
    {
        g << it.getid() << ";" << it.getdescr() << ";" << it.getstare() << ";";
        for (int i=0;i<it.getprogramatori().size()-1;i++)
            g << it.getprogramatori()[i] << ",";
        g << it.getprogramatori()[it.getprogramatori().size() - 1];
        g << "\n";
    }
    g.close();
}

void RepoTask::update(Task t)
{
    for(auto &it: tasks)
        if (it.getid() == t.getid())
        {
            it.setstare(t.getstare());
            break;
        }
}


