#include "task.h"

int Task::getid()
{
	return id;
}

string Task::getdescr()
{
	return descr;
}

string Task::getstare()
{
	return stare;
}

vector<string> Task::getprogramatori()
{
	return programatori;
}

void Task::setstare(string newstare) {
	stare = newstare;
}
