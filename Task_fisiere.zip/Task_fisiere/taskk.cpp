#include "taskk.h"

taskk::taskk(ServTask& s) : serv{ s }
{
    init();
    init_connect();
}

taskk::~taskk()
{}

SecondWd::SecondWd(ServTask& s, string st) : serv{ s }, str{st}
{
    serv.addObserver(this);
    init();
    init_connect();
}

SecondWd::~SecondWd()
{}
