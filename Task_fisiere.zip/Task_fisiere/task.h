#pragma once
#include <string>
#include <vector>
using namespace std;
class Task {
private:
	int id;
	string descr, stare;
	vector<string> programatori;
public:
	Task(int i, string d, string s, vector<string> p) : id{ i }, descr{ d }, stare{ s }, programatori{ p } {}
	int getid();
	string getdescr();
	string getstare();
	vector<string> getprogramatori();
	void setstare(string newstare);
};