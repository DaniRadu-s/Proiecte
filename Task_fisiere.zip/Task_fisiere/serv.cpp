#include "serv.h"

vector<Task> ServTask::getAllService()
{
	return sort(repo.getAll());
}

vector<Task> ServTask::sort(vector<Task> v)
{
	for(int i=0;i<v.size()-1;i++)
		for(int j=i+1;j<v.size();j++)
			if (v[i].getstare() > v[j].getstare())
			{
				Task aux = v[i];
				v[i] = v[j];
				v[j] = aux;
			}
	return v;
}

void ServTask::adaugare_s(int id, string d, string s, vector<string> p)
{
	repo.adaugare(Task{ id, d, s, p });
}

void ServTask::update_s(int id, string d, string s, vector<string> p)
{
	repo.update(Task{ id,d,s,p });
}
