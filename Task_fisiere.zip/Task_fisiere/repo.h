#pragma once
#include "task.h"
#include <fstream>
#include <sstream>
class RepoTask {
private:
	string filename;
	vector<Task> tasks;
public:
	RepoTask(string f) : filename{ f } {
		load_from_file();
	}
	void load_from_file();
	vector<Task> getAll();
	void adaugare(Task t);
	void save_to_file();
	void update(Task t);
};