#pragma once
#include "repo.h"
#include "Observer.h"
class ServTask : public ObserverManager {
private:
	RepoTask& repo;
public:
	ServTask(RepoTask& r) : repo{ r } {}
	vector<Task> getAllService();
	vector<Task> sort(vector<Task> v);
	void adaugare_s(int id, string d, string s, vector<string> p);
	void update_s(int id, string d, string s, vector<string> p);
};