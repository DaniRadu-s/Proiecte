#pragma once
#include <vector>
#include <string>

using namespace std;

class Observer
{
public:
	virtual ~Observer() = default;
	virtual void update() = 0;
};

class ObserverManager
{
private:
	std::vector<Observer*> observers;
public:
	void addObserver(Observer* o)
	{
		observers.push_back(o);
	}
	void notify()
	{
		for (auto o : observers)
			o->update();
	}
};