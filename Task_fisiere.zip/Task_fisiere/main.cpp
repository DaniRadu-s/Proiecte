#include "taskk.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    RepoTask rep{ "tasks.txt" };
    ServTask serv{ rep };
    taskk w{ serv };
    w.show();
    return a.exec();
}
