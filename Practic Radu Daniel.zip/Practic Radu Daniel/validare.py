from domain import melodie
from datetime import datetime
class valid:
    def __init__(self):
        pass
    @staticmethod
    def validare_melodie(melodie):
        titlu = melodie.get_titlu()
        artist = melodie.get_artist()
        gen = melodie.get_gen()
        data = melodie.get_data()

        date = data.split(".")
        ziua = int(date[0])
        luna = int(date[1])
        an = int(date[2])
        err = ""
        """
        Verificam data
        """
        if len(data) != 10:
            err += 'Data invalida!\n'
        if an <=0:
            err += 'Data nu este valida!\n'
        elif (luna == 1 or luna == 3 or luna == 5 or luna == 7 or luna == 8
                or luna == 10 or luna == 12) and (ziua>31 or ziua<1):
            err += 'Data nu este valida!'
        elif (luna == 4 or luna == 6 or luna == 9 or luna == 11) and (ziua>30 or ziua<1):
            err += 'Data nu este valida!\n'
        elif luna == 2 and (ziua>28 or ziua<1):
            err += 'Data nu este valida!\n'
        """
        Verificam genul sa fie unul din cele 3
        """
        if gen not in ['Rock', 'Pop', 'Jazz']:
            err += 'Genul nu este Rock, Pop sau Jazz!\n'

        """
        Verificam ca titlul si artistul sa fie nevizi
        """
        if len(titlu)<=0:
            err += 'Titlu invalid\n'
        if len(artist) <= 0:
            err += 'Artist invalid\n'

        if err != "":
            raise ValueError(err)