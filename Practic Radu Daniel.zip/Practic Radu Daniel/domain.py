class melodie:
    """
    formam clasa melodiei
    """
    def __init__(self, titlu, artist, gen, data):
        self.titlu = titlu
        self.artist = artist
        self.gen = gen
        self.data = data

    """
    getere si setere
    """
    def get_titlu(self):
        return self.titlu
    def get_artist(self):
        return self.artist
    def get_gen(self):
        return self.gen
    def get_data(self):
        return self.data

    def set_titlu(self, new_title):
        self.titlu = new_title
    def set_artist(self, new_artist):
        self.artist = new_artist
    def set_gen(self, new_gen):
        self.gen = new_gen
    def set_data(self, new_data):
        self.data = new_data
    """
    afisaj
    """
    def __str__(self):
        return f"Titlu: {self.titlu}, Artist: {self.artist}, Gen: {self.gen}, Data: {self.data}"