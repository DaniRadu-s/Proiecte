from validare import valid
from repository import repo_melodie
from service import service_melodie
from ui import console

"""
meniul principal
"""
meniu = console(service_melodie(repo_melodie("melodii.txt"),valid))
meniu.start_ui()