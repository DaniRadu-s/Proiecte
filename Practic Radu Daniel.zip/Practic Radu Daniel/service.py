from domain import melodie
from random import *

"""
functie de mergesort
"""
def mergesort(l, st, dr):
    if dr-st<=1:
        return
    m = len(l)//2
    mergesort(l, st, m)
    mergesort(l, m, dr)
    merge(l, st, dr, m)

def merge(l, st, dr, m):
    left = l[st:m]
    right = l[m:dr]
    i = j = 0
    k = st
    while i<len(left) and j<len(right):
        if (int(st[i].get_data()[-4:]) < int(dr[i].get_data()[-4:]) or
            int(st[i].get_data()[-4:]) == int(dr[i].get_data()[-4:]) and int(st[i].get_data()[3:5]) < int(dr[i].get_data()[3:5])
            or int(st[i].get_data()[-4:]) == int(dr[i].get_data()[-4:]) and int(st[i].get_data()[3:5]) == int(dr[i].get_data()[3:5])
            and int(st[i].get_data()[0:2]) < int(dr[i].get_data()[0:2])):
            l[k] = st[i]
            i = i+1
        else:
            l[k] = dr[j]
            j = j + 1
        k = k +1
    while i<len(left):
        l[k] = st[i]
        i = i + 1
    while i<len(right):
        l[k] = dr[j]
        j = j + 1

"""
clasa de service
"""
class service_melodie:
    def __init__(self, repo, validator):
        self.repo = repo
        self.validator = validator

    """
    functei de modificare
    """

    def modificare_service(self, titlu, artist, gen, data):
        mel = melodie(titlu,artist,gen,data)
        self.validator.validare_melodie(mel)
        self.repo.modificare(mel)

    """
    functie export
    """
    def export(self, filename):
        lista = self.repo.get_melodii()
        lista.sort(key = lambda x: (x.get_data()[-4:], x.get_data()[3:5], x.get_data()[0:2]))
        with open(filename, "w") as f:
            for melodie in lista:
                f.write(melodie.get_artist() + "," + melodie.get_titlu() + "," + melodie.get_gen() + "," + melodie.get_data()+"\n")
    """
    functie meniu random
    """
    def melodii_random(self, n, titluri, artisti):
        artisti = artisti.split(",")
        for x in artisti:
            x.strip()
        titluri = titluri.split(",")
        for x in titluri:
            x.strip()
        x = len(self.repo.get_melodii())
        for i in range(n):
            titlu = choice(titluri)
            artist = choice(artisti)
            gen = choice(['Rock', 'Pop', 'Jazz'])
            zi = randint(1,28)
            luna = randint(1,12)
            an = randint(1950,2024)
            if zi<10 and luna<10:
                data = "0"+str(zi)+".0"+str(luna)+"."+str(an)
            elif zi<10:
                data = "0" + str(zi) + "." + str(luna) +"."+ str(an)
            elif luna<10:
                data = str(zi) + ".0" + str(luna) +"."+ str(an)
            else:
                data = str(zi) +"." + str(luna) +"."+ str(an)
            mel = melodie(titlu,artist,gen, data)
            self.validator.validare_melodie(mel)
            self.repo.add(mel)
        print(len(self.repo.get_melodii())-x)
