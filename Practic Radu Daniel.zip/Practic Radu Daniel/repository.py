from domain import melodie
"""
creez clasa de repository
"""
class repo_melodie:
    def __init__(self, filename):
        self.filename = filename
        self.melodii = []

    """
    functie salvare in fisier
    """

    def save_to_file(self):
        with open(self.filename, "w") as f:
            for melodie in self.melodii:
                f.write(melodie.get_titlu()+","+melodie.get_artist()+","+melodie.get_gen()+","+melodie.get_data()+"\n")

    """
    functie incarcare in fisier
    """
    def load_from_file(self):
        with open(self.filename, "r") as f:
            lines = f.readlines()
            for line in lines:
                line = line.strip()
                parts = line.split(",")
                mel = melodie(parts[0], parts[1], parts[2], parts[3])
                self.melodii.append(mel)

    """
    returnez lista
    """
    def get_melodii(self):
        return self.melodii

    """
    functie modificare
    """
    def modificare(self, mel):
        ok = 0
        for melodie in self.melodii:
            if melodie.get_titlu() == mel.get_titlu() and melodie.get_artist() == mel.get_artist():
                melodie.set_gen(mel.get_gen())
                melodie.set_data(mel.get_data())
                ok = 1
        if not ok:
            print("Nu exista melodia respectiva!")
        self.save_to_file()

    """
    functie adaugare
    """
    def add(self, mel):
        ok = 0
        for melodie in self.melodii:
            if melodie.get_titlu() == mel.get_titlu() and melodie.get_artist() == mel.get_artist():
                ok = 1
        if not ok:
            self.melodii.append(mel)
            self.save_to_file()

    def load_melodii(self):
        return self.load_from_file()
