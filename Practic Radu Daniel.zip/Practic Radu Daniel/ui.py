from domain import melodie
"""
clasa de ui
"""
class console:
    def __init__(self, service):
        self.service = service

    """
    functie de modificare
    """
    def modificare_ui(self):
        titlu = input("Introduceti un titlu: ")
        artist = input("Introduceti un artist: ")
        gen = input("Introduceti un gen: ")
        data = input("Introduceti un data: ")
        try:
            self.service.modificare_service(titlu,artist,gen,data)
        except ValueError as e:
            print(e)
    """
    functie de random
    """
    def random_ui(self):
        n = int(input("Introduceti un numar: "))
        titluri = input("Introduceti titluri: ")
        artisti = input("Introduceti artisti: ")
        self.service.melodii_random(n, titluri, artisti)


    """
    functie de export
    """
    def export_ui(self):
        filename = input("Introduceti nume fisier: ")
        if filename[-4:] != '.txt':
            filename += ".txt"
        self.service.export(filename)

    """
    functie de start
    """
    def start_ui(self):
        op = ""
        self.service.repo.load_melodii()
        while True:
            print("Comenzile sunt: modificare, random, export")
            op = input("Introduceti o comanda: ")
            if op == "modificare":
                self.modificare_ui()
            elif op == "random":
                self.random_ui()
            elif op == "export":
                self.export_ui()
            elif op == "exit":
                break
            else:
                print("Comanda invalida!")