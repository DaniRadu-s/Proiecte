#include "QtWidgetsApplication1.h"

Car::Car(ServMasina& s, vector<vector<Masina>> l_u): serv{s}, l_undo{l_u}
{
    init();
    init_connect();
}

Car::~Car()
{
    
}
