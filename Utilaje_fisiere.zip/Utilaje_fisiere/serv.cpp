#include "serv.h"

vector<Masina> ServMasina::getAllService()
{
	return repo.getAll();
}

void ServMasina::modificare_an_serv(string s)
{
	repo.modifica_an_repo( s);
}

void ServMasina::stergere_serv(Masina m)
{
	repo.stergere_repo(m);
}
