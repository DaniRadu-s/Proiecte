#include "domain.h"

string Masina::getnrinmat()
{
	return nrinmat;
}

string Masina::getdenum()
{
	return denumire;
}

string Masina::gettip()
{
	return tip;
}

int Masina::getan()
{
	return an;
}

void Masina::setan(int newan)
{
	an = newan;
}

void Masina::setnrinmat(string newnrinmat)
{
	nrinmat = newnrinmat;
}

void Masina::setdenum(string newdenumire)
{
	denumire = newdenumire;
}

void Masina::settip(string newtip)
{
	tip = newtip;
}
