#pragma once
#include <string>
using namespace std;
class Utilaj {
private:
	int id, cil;
	string denum, tip;
public:
	Utilaj(int i, string d, string t, int c) : id{ i }, denum{ d }, tip{ t }, cil{ c } {}
	int getid();
	int getcil();
	string getdenum();
	string gettip();
	void settip(string newtip);
	void setdenum(string newdenum);
	void setcil(int newcil);
};