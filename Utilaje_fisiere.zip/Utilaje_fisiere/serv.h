#pragma once
#include "repo.h"
//clasa de service care contine un repository masina
class ServMasina {
private:
	RepoMasina& repo;
public:
	//constructor service
	ServMasina(RepoMasina& r) : repo{ r } {}
	//returneaza lista de masini preluata din repo
	vector<Masina> getAllService();
	//apeleaza functia de modificare din repository
	void modificare_an_serv(string s);
	//sterge o masina dupa numarul de inmatriculare unic din lista de masini
	void stergere_serv(Masina m);
};