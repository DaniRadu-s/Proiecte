#include "test.h"
#include "assert.h"
#include "qdebug.h"
void test_domain() {
	Masina m ={ "a","a",1,"sedan" };
	assert(m.getnrinmat() == "a");
	assert(m.getdenum() == "a");
	assert(m.getan() == 1);
	assert(m.gettip() == "sedan");
	m.setan(19);
	assert(m.getan() == 19);
}

void test_serv_repo() {
	RepoMasina rep{ "masini.txt" };
	ServMasina serv{ rep };
	assert(serv.getAllService().size() == 10);
	assert(serv.getAllService()[0].getan() == 2000);
	serv.modificare_an_serv("-");
	assert(serv.getAllService()[0].getan() == 1999);
	serv.modificare_an_serv("+");
	assert(serv.getAllService()[0].getan() == 2000);
	serv.stergere_serv(serv.getAllService()[0]);
	assert(serv.getAllService().size() == 9);
}

void testAll()
{
	test_domain();
	test_serv_repo();
}
