#pragma once
#include "domain.h"
#include <fstream>
#include <sstream>
#include <vector>
//clasa de repository cu un fisier dat care contine un vector de masini
class RepoMasina {
private:
	vector<Masina> masini;
	string filename;
public:
	//constructor repository
	RepoMasina(string file) : filename{ file } {
		load_from_file();
	}
	//sorteaza o lista
	vector<Masina> sortare(vector<Masina> m);
	//colecteaza din fisier datele
	void load_from_file();
	//incarca in fisier datele
	void save_to_file();
	//modifica anul de fabricatie al tuturor masinilor
	void modifica_an_repo(string s);
	//sterge masina din lista de masini
	void stergere_repo(Masina m);
	//returneaza lista de masini
	vector<Masina> getAll();
};