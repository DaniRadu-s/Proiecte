#include "Utilaj.h"

int Utilaj::getid()
{
	return id;
}

int Utilaj::getcil()
{
	return cil;
}

string Utilaj::getdenum()
{
	return denum;
}

string Utilaj::gettip()
{
	return tip;
}

void Utilaj::settip(string newtip)
{
	tip = newtip;
}

void Utilaj::setdenum(string newdenum)
{
	denum = newdenum;
}

void Utilaj::setcil(int newcil)
{
	cil = newcil;
}
