#include "QtWidgetsApplication1.h"
#include <QtWidgets/QApplication>
#include "test.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //testAll();
    RepoMasina repo{ "masini.txt" };
    ServMasina serv{ repo };
    vector<vector<Masina>> l_undo;
    Car w{ serv , l_undo };
    w.show();
    return a.exec();
}
