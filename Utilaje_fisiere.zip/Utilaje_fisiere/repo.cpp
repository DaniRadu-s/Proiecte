#include "repo.h"

vector<Masina> RepoMasina::sortare(vector<Masina> m)
{
	for(int i=0;i<m.size()-1;i++)
		for(int j=i+1;j<m.size();j++)
			if (m[i].getnrinmat() > m[j].getnrinmat())
			{
				Masina aux = m[i];
				m[i] = m[j];
				m[j] = aux;
			}
	return m;
}

void RepoMasina::load_from_file()
{
	ifstream f(filename);
	if (!f.is_open())
		throw exception();
	string line;
	while (getline(f, line)) {
		istringstream iss(line);
		string nr, d, a, t;
		if (getline(iss, nr, ',') && getline(iss, d, ',') && getline(iss, a, ',') && getline(iss, t, ' '))
			masini.push_back(Masina{ nr, d, stoi(a), t });
	}
	f.close();
}

void RepoMasina::save_to_file()
{
	ofstream g(filename);
	if (!g.is_open())
		throw exception();
	for (auto& it : masini)
	{
		g << it.getnrinmat() << "," << it.getdenum() << "," << it.getan() << "," << it.gettip() << "\n";
	}
	g.close();
}

void RepoMasina::modifica_an_repo(string s)
{
	for (auto& it : masini)
	{
		if (s == "-")
			it.setan(it.getan() - 1);
		else it.setan(it.getan() + 1);
	}
	save_to_file();
}

void RepoMasina::stergere_repo(Masina m)
{
	auto it = find_if(masini.begin(), masini.end(), [&](Masina c) {
		return c.getnrinmat() == m.getnrinmat();
		});
	masini.erase(it);
	save_to_file();
}

vector<Masina> RepoMasina::getAll() {
	return sortare(masini);
}

