#pragma once
#include <QAbstractTableModel>
#include <string>
#include <vector>
#include "serv.h"
#include "domain.h"

using namespace std;

class TableModel : public QAbstractTableModel {
    vector<Masina> masini;
public:
    TableModel(vector<Masina> m) : masini{ m } {}

    int rowCount(const QModelIndex& parent) const override {
        return masini.size();
    }

    int columnCount(const QModelIndex& parent = QModelIndex()) const override {
        return 4;
    }

    void update_t(vector<Masina> m) {
        this->masini = m;
        endResetModel();
    }

    QVariant data(const QModelIndex& index, int role) const override {
        if (!index.isValid() || index.row() >= masini.size())
            return QVariant();

        if (role == Qt::DisplayRole) {
            Masina a = masini.at(index.row());
            if (index.column() == 0)
                return QString::fromStdString(a.getnrinmat());
            if (index.column() == 1)
                return QString::fromStdString(a.getdenum());
            if (index.column() == 2)
                return QString::number(a.getan());
            if (index.column() == 3)
                return QString::fromStdString(a.gettip());
        }
        else if (role == Qt::BackgroundRole)
        {
            Masina a = masini.at(index.row());
            if (a.gettip() == "sedan")
            {
                return QBrush(Qt::yellow);
            }
            if (a.gettip() == "hatch")
            {
                return QBrush(Qt::green);
            }
            if (a.gettip() == "suv")
            {
                return QBrush(Qt::red);
            }
            if (a.gettip() == "van")
            {
                return QBrush(Qt::blue);
            }
        }

        return QVariant();
    }
};