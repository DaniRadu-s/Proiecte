#pragma once
#include "serv.h"
//functie in care se testeaza programul
void testAll();