#pragma once
#include <string>
using namespace std;
// clasa unei masini care contine numar de inmatriculare, denumirea, anul fabricatie si tipul ei
class Masina {
private:
	string nrinmat, denumire, tip;
	int an;
public:
	//constructor
	Masina(string nr, string d, int a, string t) : nrinmat{ nr }, denumire{ d }, an{ a }, tip{ t } {}
	//returneaza numarul de inmatriculare
	string getnrinmat();
	//returneaza denumirea
	string getdenum();
	//returneaza tipul
	string gettip();
	//returneaza anul de fabricatie
	int getan();
	//modifica valoarea anului de fabricatie
	void setan(int newan);
	//modifica numarul de inmatriculare
	void setnrinmat(string newnrinmat);
	//modifica denumirea
	void setdenum(string newdenumire);
	//modifica tipul
	void settip(string newtip);
};