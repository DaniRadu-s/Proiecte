#pragma once

#include <QtWidgets/QWidget>
#include "ui_QtWidgetsApplication1.h"
#include "serv.h"
#include "MyTableModel.h"
#include "qtableview.h"
#include "qlayout.h"
#include "qformlayout.h"
#include "qpushbutton.h"
#include "qmessagebox.h"

class Car : public QWidget
{
    Q_OBJECT

public:
    Car(ServMasina& s, vector<vector<Masina>> l_u);
    ~Car();
    void notify() {
        model->update_t(serv.getAllService());
    }
    void init() {
        setLayout(mainly);
        tbl->setModel(model);
        mainly->addWidget(tbl);
        mainly->addLayout(secly);
        secly->addRow("Adauga 1 la anul de fabricatie: ", add);
        secly->addRow("Scade 1 din anul de fabricatie: ", del);
        secly->addRow("Sterge elementele selectate: ", stg);
        secly->addRow("", und);
        secly->addRow("", rd);

    }
    void creste_an() {
        serv.modificare_an_serv("+");
        l_undo.push_back(serv.getAllService());
        notify();
    }
    void scade_an() {
        serv.modificare_an_serv("-");
        l_undo.push_back(serv.getAllService());
        notify();
    }
    void stergere() {
        auto index = tbl->selectionModel()->selectedRows();
        for(int i=0;i<index.size();i++)
        {
            serv.stergere_serv(serv.getAllService()[index[i].row()]);
        }
        l_undo.push_back(serv.getAllService());
        notify();
    }
    void undo() {
        if (l_undo.size() > 0)
        {
            for (int i=0; i<serv.getAllService().size();i++)
            {
                serv.getAllService()[i].setnrinmat(l_undo[l_undo.size() - 1][i].getnrinmat());
                serv.getAllService()[i].setdenum(l_undo[l_undo.size() - 1][i].getdenum());
                serv.getAllService()[i].settip(l_undo[l_undo.size() - 1][i].gettip());
                serv.getAllService()[i].setan(l_undo[l_undo.size() - 1][i].getan());
            }
            l_undo.pop_back();
            notify();
        }
        else QMessageBox::warning(nullptr, "Info", "Nu se mai poate da Undo");
    }
    void redo() {
        vector<Masina> vec = serv.getAllService();
        for (int i = 0; i < serv.getAllService().size();i++)
            {
                serv.getAllService()[i].setnrinmat(vec[i].getnrinmat());
                serv.getAllService()[i].setdenum(vec[i].getdenum());
                serv.getAllService()[i].settip(vec[i].gettip());
                serv.getAllService()[i].setan(vec[i].getan());
            }
        notify();
    }
    void init_connect() {
        QObject::connect(add, &QPushButton::clicked, this, &Car::creste_an);
        QObject::connect(del, &QPushButton::clicked, this, &Car::scade_an);
        QObject::connect(stg, &QPushButton::clicked, this, &Car::stergere);
        QObject::connect(und, &QPushButton::clicked, this, &Car::undo);
        QObject::connect(rd, &QPushButton::clicked, this, &Car::redo);
    }

private:
    ServMasina& serv;
    vector<vector<Masina>> l_undo;
    QTableView* tbl = new QTableView;
    TableModel* model = new TableModel{ serv.getAllService() };
    QHBoxLayout* mainly = new QHBoxLayout;
    QFormLayout* secly = new QFormLayout;
    QPushButton* add = new QPushButton{ "+" };
    QPushButton* del = new QPushButton{ "-" };
    QPushButton* stg = new QPushButton{ "Sterge" };
    QPushButton* und = new QPushButton{ "Undo" };
    QPushButton* rd = new QPushButton{ "Redo" };
};
