package com.example.guiex1.controller;

import com.example.guiex1.domain.Prietenie;
import com.example.guiex1.domain.Tuple;
import com.example.guiex1.domain.Utilizator;
import com.example.guiex1.services.UtilizatorService;
import com.example.guiex1.utils.events.Event;
import com.example.guiex1.utils.events.FriendshipEntityChangeEvent;
import com.example.guiex1.utils.events.UtilizatorEntityChangeEvent;
import com.example.guiex1.utils.observer.Observer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import javafx.event.ActionEvent;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class FriendController implements Observer<Event> {
    public javafx.scene.control.Label Label;
    UtilizatorService service;
    ObservableList<Utilizator> model = FXCollections.observableArrayList();

    long idf;
    @FXML
    private TableView<Utilizator> tableView;
    @FXML
    private TableColumn<Utilizator, String> FirstName;
    @FXML
    private TableColumn<Utilizator, String> LastName;
    Stage dialogStage;
    Utilizator utilizator;

    public void setService(UtilizatorService service,  Stage stage, Utilizator u) {
        this.service = service;
        this.dialogStage=stage;
        this.utilizator =u;
        Label.setText(utilizator.getFirstName() + " " + utilizator.getLastName());
        service.addObserver(this);
        initModel();
    }


    @Override
    public void update(Event event) {
        this.utilizator = service.searchUser(this.utilizator.getId());
        if(event.getClass()==FriendshipEntityChangeEvent.class) {
            if(((FriendshipEntityChangeEvent) event).getData().getId().getRight().equals(utilizator.getId())) {
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "New ","Ai o cerere de prietenie noua");
            }
        }
        initModel();
    }

    private void initModel() {
        Iterable<Tuple<Utilizator,String>> messages = utilizator.getFriends();
        List<Utilizator> users = StreamSupport.stream(messages.spliterator(), false)
                .filter(u->"active".equals(u.getRight())).map(u->u.getLeft())
                .collect(Collectors.toList());
        model.setAll(users);
    }

    public void handleRemove(ActionEvent event) {
        Utilizator user=(Utilizator) tableView.getSelectionModel().getSelectedItem();
        if (user!=null) {
            Tuple<Long, Long> id = new Tuple<>(user.getId(), utilizator.getId());
            Prietenie deleted= service.deleteFriendship(id);
            MessageAlert.showMessage(null, Alert.AlertType.CONFIRMATION,"Delete friendship","Prietenia a fost stearsa");
        }
        else MessageAlert.showErrorMessage(null, "NU ati selectat nici un utilizator");
    }

    @FXML
    public void initialize() {
        LastName.setCellValueFactory(new PropertyValueFactory<Utilizator, String>("lastName"));
        FirstName.setCellValueFactory(new PropertyValueFactory<Utilizator, String>("firstName"));
        tableView.setItems(model);
    }

    public void handleAdd(ActionEvent event) {
        long id=0;
        try {
            // create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("../views/add-friend-view.fxml"));

            AnchorPane root = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Adaugare prieteni");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            //dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            AddFriendController addfriendController = loader.getController();
            addfriendController.setService(service, dialogStage,this.utilizator);
            dialogStage.show();

        } catch ( IOException e) {
            e.printStackTrace();
        }
    }

    public void handleRequest(ActionEvent event) {
        try {
            // create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("../views/friend-requests-view.fxml"));

            AnchorPane root = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Friend Requests");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            //dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            FriendRequestController friendRequestController = loader.getController();
            friendRequestController.setService(service, dialogStage, this.utilizator);

            dialogStage.show();

        } catch ( IOException e) {
            e.printStackTrace();
        }

    }

    public void handleChange(ActionEvent actionEvent) {
        try {
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("../views/change-view.fxml"));

                AnchorPane root = (AnchorPane) loader.load();

                // Create the dialog Stage.
                Stage dialogStage = new Stage();
                dialogStage.setTitle("Change");
                dialogStage.initModality(Modality.WINDOW_MODAL);
                //dialogStage.initOwner(primaryStage);
                Scene scene = new Scene(root);
                dialogStage.setScene(scene);

                ChangeController registerController = loader.getController();
                registerController.setService(service, dialogStage, utilizator);

                dialogStage.show();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    public void handleOpenChat(ActionEvent actionEvent){
        Utilizator friend=(Utilizator) tableView.getSelectionModel().getSelectedItem();
        if(friend==null){
            MessageAlert.showErrorMessage(null,"Vorbesti singur");
            return;
        }
        try {
            // create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("../views/message-view.fxml"));

            AnchorPane root = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("ChatGPT");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            //dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            MessageController messageController = loader.getController();
            messageController.setService(service, this.utilizator,friend);

            dialogStage.show();

        } catch ( IOException e) {
            e.printStackTrace();
        }
    }

    public void handleGroupChat(ActionEvent actionEvent) {
        try {
            // create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("../views/group-view.fxml"));

            AnchorPane root = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Group Chat");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            //dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(root);
            dialogStage.setScene(scene);

            GroupController groupController = loader.getController();
            groupController.setService(service, dialogStage, utilizator);

            dialogStage.show();

        } catch ( IOException e) {
            e.printStackTrace();
        }
    }
}
