package com.example.guiex1.utils.events;

public interface Event {
}
